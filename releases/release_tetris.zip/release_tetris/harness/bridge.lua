-- bridge.lua (Tetris; copied from TMNT/bridge.lua 2026-11-13) : runs inside EmuHawk (BizHawk 2.11.1, NesHawk).
-- Connects to the Python controller over TCP and executes newline-delimited commands, replying one line per command.
-- The bridge knows nothing about the game: the RAM fields reported in every state
-- line are sent from Python (`fields name:addr,...`).
--
-- Commands:
--   ping                        -> pong
--   step <n> <buttons>          -> hold <buttons> (comma list or "-") for n frames, reply state
--   stepx <hex>                 -> one frame per 2 hex digits (button mask, see MASKBITS), reply state
--   stepc <padaddr> <carry> <hex> -> stepx with lost-press compensation (see below)
--   until <addr> <op> <val> <max> <buttons>  -> hold buttons until RAM[addr] op val (op: eq ne lt gt and)
--                                   or max frames; reply "<frames stepped>|<state>"
--   state                       -> reply state
--   fields name:addr,...        -> which RAM bytes a state line reports
--   trace on|off                -> step/stepx reply one state line per frame, joined by ";"
--   ram <addr> <len>            -> hex bytes of main RAM
--   ramd <domain> <addr> <len>  -> hex bytes of any memory domain (e.g. OAM, PALRAM, "PPU Bus", "System Bus")
--   domains                     -> memory domain names
--   coreinfo                    -> system id, board, preferred core, domains
--   save <path> | load <path>   -> savestate to/from file
--   msave | mload <id> | mfree <id>   -> in-memory savestates
--   screenshot <path>           -> png of the frame last emulated
--   fast | normal | frameskip n | invis on|off -> unthrottle / throttle / draw every nth frame / no rendering
--   reset                       -> power-cycle core
--   poke <addr> <val>           -> DEBUG ONLY, never used by a run
--   watch <kind> <addr>         -> DEBUG/RESEARCH: count the PC of every write/read/exec of <addr> (kind w|r|x)
--   watchget                    -> "addr:kind:pc:count,..." accumulated since the last watchclear
--   watchclear                  -> remove all watches (not the tick)
--   tick name:addr[:hexsig],...|off -> state lines carry name=<executions of addr during the last frame>; with
--                                   :hexsig only while the bytes mapped at addr.. equal hexsig (right PRG bank).
--   quit                        -> exit EmuHawk
--
-- State line: frame=<emu.framecount> <fields...> lag=<emu.lagcount> lagged=<0|1: was the last frame a lag frame>
-- (BizHawk's "lag frame" = a frame on which the game did not read the controller port $4016.)

local socket = require("socket.core")

local port = tonumber(userdata.get("port") or 0)
if not port or port == 0 then
  local f = io.open("<project>/.bridge_port", "r")
  if f then port = tonumber(f:read("*l")); f:close() end
end
assert(port and port > 0, "bridge: no port given")

local conn = socket.tcp()
conn:settimeout(15)
local ok, err = conn:connect("127.0.0.1", port)
assert(ok, "bridge: connect failed: " .. tostring(err))
conn:setoption("tcp-nodelay", true)
conn:settimeout(0.05)
console.log("bridge: connected on port " .. port)

local FIELDS = {}

local BUTTONS = {"Up","Down","Left","Right","Select","Start","B","A"}
-- mask bits = the standard NES shift-register order read MSB first: A B Select Start Up Down Left Right
local MASKBITS = {{128,"A"},{64,"B"},{32,"Select"},{16,"Start"},{8,"Up"},{4,"Down"},{2,"Left"},{1,"Right"}}
TRACE = false

-- exec counters (see `tick`): TICKS[i] = {name, id, count, prev}
TICKS = {}
function adv()
  for _, t in ipairs(TICKS) do t[4] = t[3] end
  emu.frameadvance()
end

local function state_str()
  local p = {"frame=" .. emu.framecount()}
  for _, t in ipairs(TICKS) do p[#p+1] = t[1] .. "=" .. (t[3] - t[4]) end
  for _, f in ipairs(FIELDS) do
    p[#p+1] = f[1] .. "=" .. mainmemory.read_u8(f[2])
  end
  p[#p+1] = "lag=" .. emu.lagcount()
  p[#p+1] = "lagged=" .. (emu.islagged() and 1 or 0)
  return table.concat(p, " ")
end

local function parse_buttons(s)
  local t = {}
  for _, b in ipairs(BUTTONS) do t[b] = false end
  if s and s ~= "-" then
    for b in string.gmatch(s, "[^,+]+") do t[b] = true end
  end
  return t
end

local MASKCACHE = {}
local function mask_buttons(m)
  local t = MASKCACHE[m]
  if t then return t end
  t = {}
  local v = m
  for _, mb in ipairs(MASKBITS) do
    if v >= mb[1] then t[mb[2]] = true; v = v - mb[1] else t[mb[2]] = false end
  end
  MASKCACHE[m] = t
  return t
end

local function tohex(arr)
  local out = {}
  for i = 0, #arr do
    if arr[i] ~= nil then out[#out+1] = string.format("%02x", arr[i]) end
  end
  return table.concat(out)
end

HEX = {}
for i = 0, 255 do HEX[i] = string.format("%02x", i) end

local function send(line)
  conn:settimeout(30)
  conn:send(line .. "\n")
  conn:settimeout(0.05)
end

-- research watches: WATCH[key] = count, key = addr:kind:pc
local WATCH = {}
local WATCHIDS = {}

local function handle(line)
  local cmd, rest = line:match("^(%S+)%s*(.*)$")
  if cmd == "ping" then
    send("pong")
  elseif cmd == "step" then
    local n, btn = rest:match("^(%d+)%s*(%S*)$")
    n = tonumber(n) or 1
    local t = parse_buttons(btn)
    if TRACE then
      local lines = {}
      for _ = 1, n do
        joypad.set(t, 1)
        adv()
        lines[#lines+1] = state_str()
      end
      send(table.concat(lines, ";"))
    else
      for _ = 1, n do
        joypad.set(t, 1)
        adv()
      end
      send(state_str())
    end
  elseif cmd == "stepx" then
    local lines = {}
    for i = 1, #rest - 1, 2 do
      joypad.set(mask_buttons(tonumber(rest:sub(i, i + 1), 16)), 1)
      adv()
      if TRACE then lines[#lines+1] = state_str() end
    end
    if TRACE then send(table.concat(lines, ";")) else send(state_str()) end
  elseif cmd == "stepc" then
    -- stepc <pad addr> <carry mask> <hex>: stepx with "lost press" compensation: every button that was sent but
    -- is missing from the game's own held-buttons byte (RAM <pad addr>, same bit layout as MASKBITS) after a
    -- non-lag frame is pressed again on the next frame. Reply: "<hex really sent>|<final carry>|<state/trace>".
    local pa, carry, hex = rest:match("^(%d+)%s+(%d+)%s+(%x*)$")
    pa = tonumber(pa); carry = tonumber(carry)
    local lines, sent = {}, {}
    for i = 1, #hex - 1, 2 do
      local want = tonumber(hex:sub(i, i + 1), 16)
      local m = want
      if carry ~= 0 then
        for _, mb in ipairs(MASKBITS) do
          if carry % (mb[1] * 2) >= mb[1] and m % (mb[1] * 2) < mb[1] then m = m + mb[1] end
        end
      end
      joypad.set(mask_buttons(m), 1)
      adv()
      sent[#sent+1] = string.format("%02x", m)
      carry = 0
      if not emu.islagged() then
        local pad = mainmemory.read_u8(pa)
        if pad ~= m then
          for _, mb in ipairs(MASKBITS) do
            if m % (mb[1] * 2) >= mb[1] and pad % (mb[1] * 2) < mb[1] then carry = carry + mb[1] end
          end
        end
      end
      if TRACE then lines[#lines+1] = state_str() end
    end
    send(table.concat(sent) .. "|" .. carry .. "|" .. (TRACE and table.concat(lines, ";") or state_str()))
  elseif cmd == "until" then
    local a, op, v, mx, btn = rest:match("^(%d+)%s+(%a+)%s+(%d+)%s+(%d+)%s*(%S*)$")
    a = tonumber(a); v = tonumber(v); mx = tonumber(mx)
    local t = parse_buttons(btn)
    local n = 0
    local lines = {}
    while n < mx do
      joypad.set(t, 1)
      adv()
      n = n + 1
      if TRACE then lines[#lines+1] = state_str() end
      local r = mainmemory.read_u8(a)
      local hit = (op == "eq" and r == v) or (op == "ne" and r ~= v) or (op == "lt" and r < v) or
                  (op == "gt" and r > v) or (op == "and" and ((r & v) ~= 0))
      if hit then break end
    end
    send(n .. "|" .. (TRACE and table.concat(lines, ";") or state_str()))
  elseif cmd == "stepr" then
    -- stepr <hex>: like stepx, reply = for every frame "<state>/<4096 hex chars of RAM $0000-$07FF>" joined by ";"
    local lines = {}
    for i = 1, #rest - 1, 2 do
      joypad.set(mask_buttons(tonumber(rest:sub(i, i + 1), 16)), 1)
      adv()
      local arr = mainmemory.read_bytes_as_array(0, 2048)
      local hx = {}
      local o = (arr[0] ~= nil) and -1 or 0
      for k = 1, 2048 do hx[k] = HEX[arr[k + o]] end
      lines[#lines+1] = state_str() .. "/" .. table.concat(hx)
    end
    send(table.concat(lines, ";"))
  elseif cmd == "expand" then
    -- expand <sid> <keep 0|1> <ranges a:len,a:len> <hex>;<hex>;... : for every input sequence, load memory state
    -- <sid>, play it, and report "<new sid or ->/<framecount>/<lagcount>/<hex of the RAM ranges>"; replies joined by ";".
    local sid, keep, ranges, seqs = rest:match("^(%S+)%s+(%d)%s+(%S+)%s+(%S+)$")
    local rg = {}
    for a, l in string.gmatch(ranges, "(%d+):(%d+)") do rg[#rg+1] = {tonumber(a), tonumber(l)} end
    local out = {}
    for hex in string.gmatch(seqs, "[^;]+") do
      memorysavestate.loadcorestate(sid)
      for i = 1, #hex - 1, 2 do
        joypad.set(mask_buttons(tonumber(hex:sub(i, i + 1), 16)), 1)
        adv()
      end
      local hx = {}
      for _, r in ipairs(rg) do
        local arr = mainmemory.read_bytes_as_array(r[1], r[2])
        local o = (arr[0] ~= nil) and -1 or 0
        for k = 1, r[2] do hx[#hx+1] = HEX[arr[k + o]] end
      end
      local nsid = "-"
      if keep == "1" then nsid = memorysavestate.savecorestate() end
      out[#out+1] = nsid .. "/" .. emu.framecount() .. "/" .. emu.lagcount() .. "/" .. table.concat(hx)
    end
    send(table.concat(out, ";"))
  elseif cmd == "expandf" then
    -- expandf <state file> <out prefix> <ranges> <hex>;<hex>;... : like expand, but loads the parent from a state
    -- file and saves child i to "<out prefix>_<i>.State"; reply "<framecount>/<lagcount>/<hex RAM>" joined by ";".
    local src, pre, ranges, seqs = rest:match("^(%S+)%s+(%S+)%s+(%S+)%s+(%S+)$")
    local rg = {}
    for a, l in string.gmatch(ranges, "(%d+):(%d+)") do rg[#rg+1] = {tonumber(a), tonumber(l)} end
    savestate.load(src, true)
    local base = memorysavestate.savecorestate()
    local out = {}
    local i = 0
    for hex in string.gmatch(seqs, "[^;]+") do
      memorysavestate.loadcorestate(base)
      for k = 1, #hex - 1, 2 do
        joypad.set(mask_buttons(tonumber(hex:sub(k, k + 1), 16)), 1)
        adv()
      end
      local hx = {}
      for _, r in ipairs(rg) do
        local arr = mainmemory.read_bytes_as_array(r[1], r[2])
        local o = (arr[0] ~= nil) and -1 or 0
        for k = 1, r[2] do hx[#hx+1] = HEX[arr[k + o]] end
      end
      savestate.save(pre .. "_" .. i .. ".State", true)
      out[#out+1] = emu.framecount() .. "/" .. emu.lagcount() .. "/" .. table.concat(hx)
      i = i + 1
    end
    memorysavestate.removestate(base)
    send(table.concat(out, ";"))
  elseif cmd == "mfreen" then
    for id in string.gmatch(rest, "%S+") do memorysavestate.removestate(id) end
    send("ok")
  elseif cmd == "fields" then
    FIELDS = {}
    for name, addr in string.gmatch(rest, "([%w_]+):(%d+)") do
      FIELDS[#FIELDS+1] = {name, tonumber(addr)}
    end
    send("ok " .. #FIELDS)
  elseif cmd == "poke" then
    -- DEBUG ONLY (debug states, mechanics experiments). Never used by a run: runs are inputs only.
    local a, v = rest:match("^(%d+)%s+(%d+)$")
    mainmemory.write_u8(tonumber(a), tonumber(v)); send("ok")
  elseif cmd == "watch" then
    local kind, a = rest:match("^(%a)%s+(%d+)$")
    a = tonumber(a)
    local function cb()
      local pc = emu.getregister("PC")
      local key = a .. ":" .. kind .. ":" .. tostring(pc)
      WATCH[key] = (WATCH[key] or 0) + 1
    end
    local id
    if kind == "w" then id = event.on_bus_write(cb, a)
    elseif kind == "r" then id = event.on_bus_read(cb, a)
    else id = event.on_bus_exec(cb, a) end
    WATCHIDS[#WATCHIDS+1] = id
    send("ok " .. tostring(id))
  elseif cmd == "tick" then
    for _, t in ipairs(TICKS) do event.unregisterbyid(t[2]) end
    TICKS = {}
    if rest ~= "off" then
      for name, a, sig in string.gmatch(rest, "([%w_]+):(%d+):?(%x*)") do
        local t = {name, nil, 0, 0}
        a = tonumber(a)
        if sig ~= "" then
          -- count only while the bytes mapped at a..a+n-1 are <sig> (the right PRG bank is in the $8000 window)
          local want = {}
          for i = 1, #sig - 1, 2 do want[#want+1] = tonumber(sig:sub(i, i + 1), 16) end
          t[2] = event.on_bus_exec(function()
            for i = 1, #want do
              if memory.read_u8(a + i - 1, "System Bus") ~= want[i] then return end
            end
            t[3] = t[3] + 1
          end, a)
        else
          t[2] = event.on_bus_exec(function() t[3] = t[3] + 1 end, a)
        end
        TICKS[#TICKS+1] = t
      end
    end
    send("ok " .. #TICKS)
  elseif cmd == "watchget" then
    local out = {}
    for k, c in pairs(WATCH) do out[#out+1] = k .. ":" .. c end
    send(table.concat(out, ","))
  elseif cmd == "watchclear" then
    for _, id in ipairs(WATCHIDS) do event.unregisterbyid(id) end
    WATCHIDS = {}; WATCH = {}; send("ok")
  elseif cmd == "trace" then
    TRACE = (rest == "on"); send("ok")
  elseif cmd == "state" then
    send(state_str())
  elseif cmd == "ram" then
    local a, l = rest:match("^(%d+)%s+(%d+)$")
    local arr = mainmemory.read_bytes_as_array(tonumber(a), tonumber(l))
    send(tohex(arr))
  elseif cmd == "ramd" then
    -- domain names may contain spaces ("PPU Bus"): Python sends them with "_" for " "
    local dom, a, l = rest:match("^(%S+)%s+(%d+)%s+(%d+)$")
    dom = dom:gsub("_", " ")
    local arr = memory.read_bytes_as_array(tonumber(a), tonumber(l), dom)
    send(tohex(arr))
  elseif cmd == "domains" then
    local names = {}
    local d = memory.getmemorydomainlist()
    for i = 0, 64 do if d[i] ~= nil then names[#names+1] = tostring(d[i]) end end
    send(table.concat(names, "|"))
  elseif cmd == "coreinfo" then
    local names = {}
    local d = memory.getmemorydomainlist()
    for i = 0, 64 do if d[i] ~= nil then names[#names+1] = tostring(d[i]) end end
    local board = "?"
    pcall(function() board = tostring(emu.getboardname()) end)
    local pref = "?"
    pcall(function() pref = tostring(client.getconfig().PreferredCores["NES"]) end)
    local hash = "?"
    pcall(function() hash = tostring(gameinfo.getromhash()) end)
    send("sys=" .. tostring(emu.getsystemid()) .. ";board=" .. board .. ";pref=" .. pref ..
         ";framecount=" .. emu.framecount() .. ";romhash=" .. hash .. ";domains=" .. table.concat(names, "|"))
  elseif cmd == "msave" then
    send(memorysavestate.savecorestate())                    -- in-RAM state, fast
  elseif cmd == "mload" then
    memorysavestate.loadcorestate(rest); send("ok")
  elseif cmd == "mfree" then
    memorysavestate.removestate(rest); send("ok")
  elseif cmd == "save" then
    savestate.save(rest, true); send("ok")
  elseif cmd == "load" then
    local r = savestate.load(rest, true); send(r and "ok" or "fail")
  elseif cmd == "screenshot" then
    client.screenshot(rest); send("ok")
  elseif cmd == "fast" then
    emu.limitframerate(false); client.SetSoundOn(false); send("ok")
  elseif cmd == "normal" then
    emu.limitframerate(true); send("ok")
  elseif cmd == "frameskip" then
    client.frameskip(tonumber(rest) or 0); send("ok")
  elseif cmd == "invis" then
    client.invisibleemulation(rest == "on"); send("ok")
  elseif cmd == "speed" then
    client.speedmode(tonumber(rest) or 100); send("ok")
  elseif cmd == "reset" then
    client.reboot_core(); send(state_str())
  elseif cmd == "quit" then
    send("bye"); conn:close(); client.exit()
  else
    send("err unknown command: " .. tostring(cmd))
  end
end

client.unpause()
-- Block for commands. Yielding while idle lets the emulator free-run (frames advanced with no
-- input from us and broke replay determinism), so the script holds the main thread instead.
conn:settimeout(nil)
while true do
  local line, e = conn:receive("*l")
  if line then
    local okh, herr = pcall(handle, line)
    if not okh then send("err " .. tostring(herr)) end
  elseif e == "closed" then
    console.log("bridge: connection closed, exiting")
    client.exit()
    break
  end
end
