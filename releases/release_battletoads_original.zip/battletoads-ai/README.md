# An AI vs Battletoads (NES): the harness, the journal, and the 12:23 run

This is everything behind the video. It has the tools the AI (Claude, working in Claude Code) wrote for itself, the
journal it kept while working, every search and probe script it ran, and the input file of the final run: **12:23.39**
on the speedrun clock, in Battletoads (NES), Any% (No Credits Warp). The human world record at the time was 12:29.25
by jay_cee.

**Deliberately left out:**
- The game ROM. Bring your own.
- Emulator save states and the multi-gigabyte captures.
- The TASVideos movies and other people's documentation that the AI read (linked below).

Nothing here plays without your own copy of the cartridge.

## Watch your own computer play the run (two minutes)

1. Install [BizHawk 2.11.1](https://tasvideos.org/BizHawk). Keep the default NES core, **QuickNes**.
2. Load your own dump of *Battletoads (USA)*. BizHawk should identify it as SHA-1 `5C3A497A82BE60704DEDF45248B6AD9B32C855AB`.
3. Go to **File → Movie → Play Movie** and choose `run/battletoads_ai_12m23s.bk2`.

The movie is the run: every button on every frame from power-on. Other files in `run/`:

| file | what |
|---|---|
| `inputs.txt` | the same inputs as plain text, one line per frame |
| `why.txt` | the notes the AI attached as it built each part. These are the WHAT/WHY lines shown in the video. |
| `token_log.jsonl` | what it cost, mark by mark |
| `VERIFICATION.txt` | the replay check: the movie, played hands-off, ends with the same 2 KB of RAM as the verified run, SHA-1 `e2a1d2dc…` |

You can check that yourself with `verify_movie.lua`; the instructions are inside it.

## Run the harness yourself

```
pip install -r requirements.txt
python smoke_test.py          # launches BizHawk with the bridge and reads a frame
```

The harness expects `BizHawk-2.11.1-win-x64/` and `Battletoads/Battletoads (USA).nes` next to this folder (see
`toads/emulator.py`).

The route was built level by level:
1. Searches (`toads/beam.py`, `toads/pbeam.py`, `fightbeam.py`, `l4s.py`, `l13solve.py`, …) write segment files.
2. `assemble.py` stitches the segments together from power-on and replays them twice, which is how every route was verified.

The `l*.py`, `*_pipeline.py`, `probe`-style and `tas*` scripts are the history: every experiment, in the order it happened.

## What is where

| path | what |
|---|---|
| `bridge.lua` | the script inside the emulator: hold buttons, read RAM, save and load states, over a socket |
| `toads/emulator.py` | the Python side of that socket, plus input logging, screenshots and replay |
| `toads/beam.py`, `toads/pbeam.py` | the beam searches over input sequences |
| `toads/ramscan.py`, `toads/dis6502.py` | finding things in memory, and a 6502 disassembler for reading the game's code |
| `assemble.py` | the final route from segments, verified by replaying from power-on twice |
| `rngfit.py`, `retjoin.py`, `oldwalk2.py`, `splice.py` | re-fitting later levels when the random numbers change |
| `make_bk2.py`, `verify_movie.lua` | the BizHawk movie and its hands-off check |
| `journal/` | the AI's journal, written as it went |
| `knowledge/` | what it found: search results, fight solutions, level notes (JSON) |
| `video_tools/` | everything that made the video: the montage, grids, memory explainers, the tower map, the chiptune, the cut |

## The rules it ran under

- **Category:** speedrun.com Battletoads (NES), Any% (No Credits Warp).
- **Allowed:** the hidden warps and the board's level-end tricks (the Turbo Tunnel bike skip, the rat boot).
- **Banned:** the credits warp, pressing Left+Right or Up+Down at the same time, and turbo.
- **The game itself:** unmodified, controller inputs only, no memory writes in a run.

Save states and search were used to build the run, which makes it a tool-assisted run (TAS), not a human run. It
does not go on the human leaderboard.

## Thank you

- jay_cee, for the record to chase.
- jc583, for the Speed Demos Archive notes.
- The TASVideos authors (https://tasvideos.org/66G): feos, Alyosha & Samsara; Lobsterzelda; MESHUGGAH & Koh1fds; Phil & Genisto.
- feos's disassembly and Lua tools.
- The DataCrystal RAM map.
- The BizHawk team.

Battletoads © 1991 Rare / Tradewest.
