"""Python side of the BizHawk bridge for Battletoads. Launches EmuHawk with bridge.lua and drives it over TCP.

Carried over from the Zelda harness with one change that matters: the bridge no longer knows the game.
Python sends it the list of RAM addresses to report (see FIELDS / set_fields), and those addresses are
found by ramscan.py, not read from any document. State fields are therefore dynamic.
"""
from __future__ import annotations

import os
import socket
import subprocess
import time
from pathlib import Path
from typing import Iterable, Sequence

PROJECT = Path(__file__).resolve().parent.parent          # G:/AI World Record/toads
ROOT = PROJECT.parent
BIZHAWK_DIR = ROOT / "BizHawk-2.11.1-win-x64"
EMUHAWK = BIZHAWK_DIR / "EmuHawk.exe"
ROM = ROOT / "Battletoads" / "Battletoads (USA).nes"
BRIDGE_LUA = PROJECT / "bridge.lua"
STATES_DIR = PROJECT / "states"
SHOTS_DIR = PROJECT / "shots"
LOGS_DIR = PROJECT / "logs"
VIDEO_DIR = PROJECT / "video"

BUTTONS = ("Up", "Down", "Left", "Right", "Select", "Start", "B", "A")

# name -> RAM address. Filled in by knowledge/ram.json once ramscan has found things; empty on day one.
FIELDS: dict[str, int] = {}


def load_fields() -> dict[str, int]:
    import json
    p = PROJECT / "knowledge" / "ram.json"
    if p.exists():
        FIELDS.clear()
        FIELDS.update({k: int(v, 0) if isinstance(v, str) else int(v) for k, v in json.loads(p.read_text()).items()})
    return FIELDS


def _click_really_quit(proc, timeout: float = 8.0) -> bool:
    """EmuHawk asks 'Really quit?' when it exits while recording A/V. Find THIS process's dialog (by pid, so
    parallel sessions do not click each other's) and press Yes, repeatedly, until the process is gone."""
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        BM_CLICK = 0x00F5
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        pid = proc.pid
        clicked = False
        t0 = time.time()
        while time.time() - t0 < timeout:
            if proc.poll() is not None:
                return clicked
            dialogs = []

            def top(h, _):
                buf = ctypes.create_unicode_buffer(64)
                u.GetWindowTextW(h, buf, 64)
                if buf.value == "Really quit?":
                    owner = wintypes.DWORD()
                    u.GetWindowThreadProcessId(h, ctypes.byref(owner))
                    if owner.value == pid:
                        dialogs.append(h)
                return True
            u.EnumWindows(EnumProc(top), 0)
            for dlg in dialogs:
                found = []

                def cb(h, _):
                    buf = ctypes.create_unicode_buffer(64)
                    u.GetWindowTextW(h, buf, 64)
                    if "yes" in buf.value.replace("&", "").lower():
                        found.append(h)
                    return True
                u.EnumChildWindows(dlg, EnumProc(cb), 0)
                if found:
                    u.PostMessageW(found[0], BM_CLICK, 0, 0)
                    clicked = True
            time.sleep(0.05)
    except Exception:
        pass
    return False


class State(dict):
    """One frame's reported RAM fields. Attribute access for convenience: s.frame, s.x, ... (0 if unknown)."""

    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            return 0

    @classmethod
    def parse(cls, line: str) -> "State":
        s = cls()
        for tok in line.split():
            k, _, v = tok.partition("=")
            s[k] = int(v)
        return s

    def __str__(self) -> str:
        return " ".join(f"{k}={v}" for k, v in self.items())


class BizHawk:
    """One EmuHawk instance driven frame by frame."""

    def __init__(self, rom: Path = ROM, fast: bool = True, log_name: str | None = None, record: str | None = None,
                 fields: dict[str, int] | None = None, movie: str | Path | None = None):
        """record=<session name>: dump A/V live (savestate jumps included) and keep every frame's input and state
        in memory so the session can be rendered with the controller panel afterwards.
        movie=<.bk2 path>: play a BizHawk movie (research only: watching a TAS); step with no buttons to let the
        movie feed the inputs (joypad.set with an empty table overrides nothing)."""
        for d in (STATES_DIR, SHOTS_DIR, LOGS_DIR, VIDEO_DIR):
            d.mkdir(parents=True, exist_ok=True)
        self.record = record
        self.trace_lines: list[str] = []
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        port = srv.getsockname()[1]
        (PROJECT / ".bridge_port").write_text(str(port))
        log_name = log_name or f"emuhawk_{int(time.time())}.log"
        log_path = LOGS_DIR / log_name
        try:
            if log_path.exists() and log_path.stat().st_size > 0:
                log_path.replace(log_path.with_name(log_path.stem + ".prev" + log_path.suffix))
        except OSError:
            pass
        self._logfile = open(log_path, "w")
        args = [str(EMUHAWK), f"--lua={BRIDGE_LUA}", f"--userdata=port:{port}"]
        if record:
            self.video_path = VIDEO_DIR / f"{record}.mkv"
            args += ["--dump-type=ffmpeg", f"--dump-name={self.video_path}"]
        if movie:
            args.append(f"--movie={movie}")
        args.append(str(rom))
        self.proc = subprocess.Popen(args, cwd=str(BIZHAWK_DIR), stdout=self._logfile, stderr=subprocess.STDOUT)
        srv.settimeout(float(os.environ.get("TOADS_CONNECT_TIMEOUT", 240)))   # a busy machine can take minutes to boot EmuHawk
        try:
            self.conn, _ = srv.accept()
        except socket.timeout:
            self.proc.kill()
            raise RuntimeError("EmuHawk never connected to the bridge; see " + str(log_path))
        finally:
            srv.close()
        self.conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.conn.settimeout(120)
        self._rf = self.conn.makefile("rb")
        self.inputs: list[tuple[str, ...]] = []   # one entry per emulated frame since power-on
        self.events: list[tuple[int, str]] = []   # (frame, text) notes from the bot, for overlays
        self.input_log_valid = True                 # False once a savestate load breaks the frame chain
        assert self.cmd("ping") == "pong"
        self.set_fields(fields if fields is not None else (FIELDS or load_fields()))
        if record:
            self.cmd("trace on")
        if fast:
            self.fast()

    # -- low level -------------------------------------------------------
    def cmd(self, line: str) -> str:
        self.conn.sendall((line + "\n").encode())
        resp = self._rf.readline()
        if not resp:
            code = None
            try:
                code = self.proc.wait(timeout=2)
            except Exception:
                pass
            how = "still running" if code is None else f"exit code {code} (0x{code & 0xFFFFFFFF:08X})"
            raise RuntimeError(f"bridge connection lost at {time.strftime('%H:%M:%S')}: EmuHawk {how}; "
                               f"log {getattr(self._logfile, 'name', '?')}")
        resp = resp.decode().rstrip("\n")
        if resp.startswith("err "):
            raise RuntimeError(resp)
        return resp

    def set_fields(self, fields: dict[str, int]) -> None:
        """Tell the bridge which RAM bytes to report with every state line."""
        self.fields = dict(fields)
        spec = ",".join(f"{k}:{v}" for k, v in fields.items())
        self.cmd(f"fields {spec}")

    # -- control ---------------------------------------------------------
    def step(self, buttons: Iterable[str] | str = (), frames: int = 1) -> State:
        if isinstance(buttons, str):
            buttons = tuple(b for b in buttons.split(",") if b)
        btn = tuple(buttons)
        for b in btn:
            if b not in BUTTONS:
                raise ValueError(f"unknown button {b!r}")
        self.inputs.extend([btn] * frames)
        resp = self.cmd(f"step {frames} {','.join(btn) or '-'}")
        if self.record:
            lines = resp.split(";")
            self.trace_lines.extend(lines)
            return State.parse(lines[-1])
        return State.parse(resp)

    def press(self, *buttons: str, hold: int = 1, release: int = 1) -> State:
        s = self.step(buttons, hold)
        if release:
            s = self.step((), release)
        return s

    def state(self) -> State:
        return State.parse(self.cmd("state"))

    def ram(self, addr: int, length: int = 1) -> bytes:
        return bytes.fromhex(self.cmd(f"ram {addr} {length}"))

    def ram_all(self) -> bytes:
        """The whole 2 KB of console RAM."""
        return self.ram(0, 0x800)

    def byte(self, addr: int) -> int:
        return self.ram(addr, 1)[0]

    def ram_domain(self, domain: str, addr: int, length: int) -> bytes:
        return bytes.fromhex(self.cmd(f"ramd {domain} {addr} {length}"))

    def save(self, name: str) -> Path:
        p = STATES_DIR / f"{name}.State"
        p.parent.mkdir(parents=True, exist_ok=True)
        self.cmd(f"save {p}")
        return p

    def load(self, name: str) -> State:
        p = STATES_DIR / f"{name}.State"
        r = self.cmd(f"load {p}")
        if r != "ok":
            raise RuntimeError(f"savestate load failed: {p}")
        self.input_log_valid = False
        return self.state()

    def poke(self, addr: int, val: int) -> None:
        """DEBUG ONLY: write one RAM byte. For mechanics experiments on snapshots; a run never calls this."""
        self.cmd(f"poke {addr} {val & 0xFF}")

    def step_movie(self, frames: int = 1) -> None:
        """Advance frames while a movie plays, without setting any input (see movie= in __init__)."""
        self.cmd(f"stepm {frames}")

    def msave(self) -> str:
        return self.cmd("msave")

    def mload(self, sid: str) -> State:
        self.cmd(f"mload {sid}")
        self.input_log_valid = False
        return self.state()

    def mfree(self, sid: str) -> None:
        self.cmd(f"mfree {sid}")

    def screenshot(self, name: str) -> Path:
        p = SHOTS_DIR / f"{name}.png"
        p.parent.mkdir(parents=True, exist_ok=True)
        self.cmd(f"screenshot {p}")
        return p

    def fast(self) -> None:
        self.cmd("fast")

    def normal(self) -> None:
        self.cmd("normal")

    def frameskip(self, n: int) -> None:
        self.cmd(f"frameskip {n}")

    def reset(self) -> State:
        self.inputs.clear()
        self.input_log_valid = True
        return State.parse(self.cmd("reset"))

    def wait(self, frames: int) -> State:
        return self.step((), frames)

    def note(self, text: str) -> None:
        """Record what the bot is doing right now (attached to the next frame)."""
        self.events.append((len(self.inputs) + 1, text))

    def save_inputs(self, name: str) -> Path:
        p = LOGS_DIR / f"{name}.inputs.txt"
        with open(p, "w") as f:
            f.write(f"# frames={len(self.inputs)} valid_from_poweron={self.input_log_valid}\n")
            for btn in self.inputs:
                f.write(",".join(btn) + "\n")
        with open(LOGS_DIR / f"{name}.events.txt", "w") as f:
            for frame, text in self.events:
                f.write(f"{frame}\t{text}\n")
        return p

    def save_session(self) -> None:
        """Write logs/<record>.{inputs,events,trace}.txt indexed by video frame (frames stepped since launch)."""
        name = self.record
        with open(LOGS_DIR / f"{name}.inputs.txt", "w") as f:
            f.write(f"# frames={len(self.inputs)} session=1\n")
            for btn in self.inputs:
                f.write(",".join(btn) + "\n")
        with open(LOGS_DIR / f"{name}.events.txt", "w") as f:
            for frame, text in self.events:
                f.write(f"{frame}\t{text}\n")
        with open(LOGS_DIR / f"{name}.trace.txt", "w") as f:
            for i, (btn, line) in enumerate(zip(self.inputs, self.trace_lines)):
                f.write(f"{i + 1}\t{','.join(btn)}\t{line}\n")

    def close(self) -> None:
        if self.record:
            try:
                self.save_session()
            except Exception as e:
                print("session save failed:", e)
        try:
            self.cmd("quit")
        except Exception:
            pass
        try:
            self.conn.close()
        except Exception:
            pass
        if self.record:
            _click_really_quit(self.proc)
        try:
            self.proc.wait(timeout=12 if self.record else 3)
        except Exception:
            self.proc.kill()
        self._logfile.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
