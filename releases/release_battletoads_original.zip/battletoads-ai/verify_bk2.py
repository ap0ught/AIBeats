"""Play a .bk2 in BizHawk through the bridge; compare its RAM with the verified capture (cap14) to find any offset."""
import hashlib, sys, zipfile
import numpy as np
from toads.emulator import BizHawk
bk2 = sys.argv[1]
n = sum(1 for l in zipfile.ZipFile(bk2).read("Input Log.txt").decode().splitlines() if l.startswith("|"))
cap = np.memmap("logs/cap14.ram", dtype=np.uint8, mode="r").reshape(-1, 2048)
e = BizHawk(log_name="verify_bk2.log", movie=bk2)
for checkpoint in (100, 1200, 2000, 5000, 20000, n):
    e.step_movie(checkpoint - getattr(e, "_pos", 0)); e._pos = checkpoint
    r = np.frombuffer(e.ram(0, 0x800), dtype=np.uint8)
    lo, hi = max(0, checkpoint - 40), min(len(cap), checkpoint + 40)
    diffs = [(k, int((cap[k] != r).sum())) for k in range(lo, hi)]
    best = min(diffs, key=lambda x: x[1])
    print(f"movie frame {checkpoint}: best cap14 row {best[0]} (offset {best[0] - checkpoint + 1}), {best[1]} bytes differ", flush=True)
print("ram sha1", hashlib.sha1(e.ram_all()).hexdigest())
e.close()
